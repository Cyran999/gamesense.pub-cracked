#pragma once

namespace GUI::Group {
	void BeginGroup( const std::string& name, const vec2_t& size );
	void EndGroup( );
}
