#pragma once

namespace GUI::Controls {
	bool Listbox(const std::string& id, std::vector<std::string> elements, std::string option, bool bSearchBar, int iSizeInElements);
}